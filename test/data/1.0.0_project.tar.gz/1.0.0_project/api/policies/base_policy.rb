class BasePolicy
  include HALPresenter::Policy::DSL
end
