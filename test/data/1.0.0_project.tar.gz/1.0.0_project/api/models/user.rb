class User < Sequel::Model
  extend Shaf::Formable


  form do
    field :name, type: "string"

    create do
      title 'Create User'
      name  'create-user'
    end

    edit do
      instance_accessor
      title 'Update User'
      name  'update-user'
    end
  end

end

