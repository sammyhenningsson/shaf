require 'policies/user_policy'

class UsersController < BaseController

  authorize_with UserPolicy

  resource_uris_for :user

  get :users_path do
    authorize! :read
    collection = paginate(User.order(:created_at).reverse)
    respond_with_collection collection, serializer: UserSerializer
  end

  get :new_user_path do
    authorize! :read
    cache_control(:private, http_cache_max_age: :short)
    respond_with create_form
  end

  post :users_path do
    authorize! :write
    user = User.create(user_params)
    headers('Location' => user_uri(user))
    respond_with user, status: 201
  end

  get :user_path do
    authorize! :read
    respond_with user
  end

  get :edit_user_path do
    authorize! :write
    cache_control(:private, http_cache_max_age: :short)
    respond_with edit_form
  end

  put :user_path do
    authorize! :write
    user.update(user_params)
    respond_with user
  end

  delete :user_path do
    authorize! :write
    user.destroy
    status 204
  end

  def user_params
    # Generated method
    # TODO: Remove any params that should not be allowed for mass update/create!
    safe_params(:name)
  end

  def user
    @user ||= User[params['id']].tap do |user|
      raise NotFoundError.new(clazz: User, id: params['id']) unless user
    end
  end

  def create_form
    User.create_form.tap do |form|
      form.self_link = new_user_uri
      form.href = users_uri
    end
  end

  def edit_form
    user.edit_form.tap do |form|
      form.self_link = edit_user_uri(user)
      form.href = user_uri(user)
    end
  end
end
