class BaseSerializer
  extend HALPresenter
  extend Shaf::UriHelper
end
