# Load your custom commands and generators in this file. E.g.
# require 'lib/my_command'
# require 'lib/my_generator'
