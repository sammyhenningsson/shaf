ENV['RACK_ENV'] = 'test'
require 'config/bootstrap'
require 'minitest/autorun'
require 'shaf/spec'
