class UserPolicy
  include HALPresenter::Policy::DSL

  # Auto generated policy: Update this file to suite your API!
 
  alias :user :resource

  attribute :name

  link :up

  link :edit, :'create-form', :'edit-form', :delete do
    write?
  end

  embed :'create-form', :'edit-form' do
    write?
  end

  def read?
    # FIXME!!
    true
  end

  def write?
    # FIXME!!
    true
  end
end
