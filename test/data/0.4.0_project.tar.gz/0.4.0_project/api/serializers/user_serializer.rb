require 'policies/user_policy'

class UserSerializer
  extend HALPresenter
  extend Shaf::UriHelper

  model User
  policy UserPolicy
  
  # FIXME: Write documentation for attribute :name
  attribute :name
  
  
  # Auto generated doc:  
  # Link to the documentation for a given relation of the user resource.
  # This link is templated, which means that {rel} must be replaced by the
  # appropriate relation name.  
  # Method: GET  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      /doc/user/rels/edit
  #```
  curie :doc do
    doc_curie_uri('user')
  end
  
  
  # Auto generated doc:  
  # Link to the collection of all users. Send a POST request to this uri to create a new user.  
  # Method: GET or POST  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      -H "Authorization: abcdef" \
  #      /users
  #```
  link :'doc:up' do
    users_uri
  end
  
  # Auto generated doc:  
  # Link to this user.  
  # Method: GET  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      -H "Authorization: abcdef" \
  #      /users/5
  #```
  link :'self' do
    user_uri(resource)
  end
  
  # Auto generated doc:  
  # Link to a form to create a new user.  
  # Method: GET  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      -H "Authorization: abcdef" \
  #      /users/form
  #```
  link :'doc:create-form' do
    new_user_uri
  end
  
  # Auto generated doc:  
  # Link to a form to edit this resource.  
  # Method: GET  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      -H "Authorization: abcdef" \
  #      /users/5/edit
  #```
  link :'doc:edit-form' do
    edit_user_uri(resource)
  end
  
  # Auto generated doc:  
  # Link to update this user.  
  # Method: PUT  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      -H "Authorization: abcdef" \
  #      -X PUT -d@payload \
  #      /users/5
  #```
  link :'doc:edit' do
    user_uri(resource)
  end
  
  # Auto generated doc:  
  # Link to delete this user.  
  # Method: DELETE  
  # Example:
  # ```
  # curl -H "Accept: application/hal+json" \
  #      -H "Authorization: abcdef" \
  #      -X DELETE \
  #      /users/5
  #```
  link :'doc:delete' do
    user_uri(resource)
  end
  
  
  # Auto generated doc:  
  # A form to edit this user
  embed :'doc:edit-form' do
    resource.edit_form.tap do |form|
      form.self_link = edit_user_uri(resource)
      form.href = user_uri(resource)
    end
  end
  
  
  collection of: 'users' do
    link :self, users_uri
    link :up, root_uri
    curie(:doc) { doc_curie_uri('user') }
  
    embed :'doc:create-form' do
      User.create_form.tap do |form|
        form.self_link = new_user_uri
        form.href = users_uri
      end
    end
  end
  
end
